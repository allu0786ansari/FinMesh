# Week 18 run log · 22 – 28 Feb 2027 · The sealed test: freeze, test mode, dry run, sign-off

**Goal (proposal: week 18):** open the sealed test once, for the frozen configurations, and decide every pre-registered hypothesis on it.

**State (6 Nov):** **the test is done.** Every hypothesis is decided on the sealed test (results just below). Still to do: the two-rater blind review, and rebuilding the HI-Medium narrative pages (step below). 

**Earlier state (2 Nov, evening):** **ready for your sign-off; the seal is still closed.** As agreed (freeze, build, dry-run, sign-off), validation work is closed and every runner now has a test path. The whole test plan has been dry-run on the fixture, including the access log and the refusal of a second opening. **Nothing opens the test until you sign `docs/protocol/test_plan.md`.**

## What you decide now

1. **Read and sign the test plan** (`docs/protocol/test_plan.md`, 10 min). It lists every opening, its seeds, metrics and decision rule, and amendment **A24**: how each parameter fitted on validation is carried to the test. A24 changes no model, feature, fusion rule, threshold, prompt or hypothesis. Three choices in it are mine and need your yes:
   - **Seeds.** At test, the headline configurations of X1 run seeds 0–4 and the others seeds 0–2 (preregistration section 7). I count the **relational oracle** as headline, because A14 made it H1b's ceiling. Each comparison averages both sides over the seeds both ran.
   - **The Holm family** is every sharing configuration's stacker compared with S0: S1, S2 and S4, S3 at five ε, and PD at three τ. That is 11 comparisons, the most conservative reading of "across the sharing levels". H1a's S2 gain was +0.56 on validation, so this choice cannot decide it.
   - **X5 is not retrained.** The test scores the DP models saved in week 12, so no privacy budget is spent twice. Only the non-private local-only MLPs, which were not saved, are retrained, with the same seed, data and steps.
2. **The blind review, both of us, after the test** (about 45 min each; your choice, 3 Nov). Rate before either of you reads the narrative test results (`docs/eval/test/narrative_*`, `RESULTS.md`, the night-3 log); X1, X5 and baseline results are fine to read. Your copy is `docs/eval/narrative_HI-Medium_A23_review_allaudin.csv`; Ravi's is `..._ravi.csv`. The instructions are in section 3 below.

## Results on the sealed test (6 Nov)

Every hypothesis was decided by its frozen rule (`docs/eval/test/RESULTS.md`; full pages beside it). Openings: 14 on HI-Medium and 14 on LI-Medium (each including its narrative), 5 on each Small set, and no repeats.

| Hypothesis | HI-Medium (primary) | LI-Medium | Small sets (replication) |
| --- | --- | --- | --- |
| **H1a** S2 raises linked detection over S0 | **Holds:** 0.136 → 0.702, gain +0.566 [0.529, 0.606], Holm p < 0.001; random 0.000 | **Holds:** 0.109 → 0.657, +0.549 [0.449, 0.634] | **Holds:** HI-Small +0.532, LI-Small +0.256 [0.111, 0.400] |
| **H1b** S2 ≥ 0.60 of the relational oracle's gain | **Holds:** 0.98 [0.94, 1.03] | **Holds:** 0.79 [0.69, 0.88] | HI-Small 0.84 holds; **LI-Small 0.47 [0.24, 0.70] misses** |
| **H1c** S1 and S3 (ε ≤ 2) attacks within 0.05 of the prior | **Holds** | **Misses:** A3 fan-in top decile, S1 +0.092, S3 ε = 2 +0.085; the leak is the alert flag, which S3 does not noise. Validation showed the same | — (no audit) |
| **H1d** PD ≥ 0.80 of S2's gain with < half the disclosure | Holds for every τ (τ = 3: 1.00 of the gain, 0.11 of the disclosure), but **uninformative**: S1 alone reaches 0.98 | Holds for every τ; also uninformative (S1 alone reaches 0.99) | Holds |
| **H2a** DP scorer ≥ 0.70 of centralised and above local-only | **Misses:** share 0.70 at ε = 3, 0.73 at ε = 10, but 0.008–0.016 below local-only | **Holds** at ε = 3 and 10 (0.77, 0.86; above local-only) | — |
| **H2b** account unit costs more than window unit | **Misses:** account above window at every ε | **Holds** at every ε (+0.004 to +0.008) | — |
| **PT4b** graph features help S0 (AUPRC) | **Holds:** +0.015 [0.009, 0.021] | **Holds:** +0.010 [0.006, 0.016] | — |
| **H3a** attribution S2 > S0 and above baselines | **Holds:** +0.044 [0.021, 0.067]; above majority and rules | **Misses:** +0.028 [−0.046, 0.089], CI includes 0 (94 schemes); above majority and rules | — |
| **H3b** ≥ 95% grounded raw replies | **Misses:** 0.86 [0.81, 0.90], 200 cases; strict (A23) 0.15 | **Misses:** 0.92 [0.84, 0.96], 76 cases; strict 0.12 | — |

**Secondary results (reported):**

| Item | HI-Medium | LI-Medium |
| --- | --- | --- |
| Artefact ablation: oracle − S0 linked, with / without the 8 artefact features (seed 0) | 0.458 / 0.372 | 0.500 / 0.319 |
| Ensemble: DP scorer added to the local detectors (G3 rule) | +0.004 at ε = 1 (CI above 0); validation showed none | +0.002 at ε = 1 |
| Token budget (A16): peak legitimate use vs frozen budget | 168,913 vs 74,510; 18.8% of token requests beyond it (served at test) | 46,634 vs 87,580; never exceeded |
| PT2: hashing ÷ OPRF re-identification at the protocol budget (≥ 10) | 19.9 | 8.7 |
| Machine time (X1 + baselines + X5 + ensemble) | 13.4 h; X1 peak memory 3.6 GB | 9.3 h; 3.2 GB |

**The narrative review (6 Nov, LLM judge; see `docs/eval/narrative_HI-Medium_A23_review_result_llm.md`).** You decided the review is done by Claude instead of human raters (amendment A23r), and it is reported as an automated judgement. Of the 27 texts the model wrote, **7 are faithful (26%)**; the template is faithful in 30 of 30 and preferred in 26. The A23 claim check accepted all 30 (kappa 0.00 with the judge). Its rules miss the model's most common error: giving the linked case's counts as the analyst's own bank's.

**What the test says, in short:**

- **RQ1 is confirmed on unseen data.** Sharing tokens and alert flags lifts linked scheme detection about fivefold on both Medium sets, matching validation (+0.56 then, +0.57 now). It recovers essentially all of the pooled relational ceiling on HI and 79% on LI.
- **Most of the value is in the alert flag.** S1 already holds 0.95–1.00 of S2’s gain. That makes H1d uninformative, and it is also the channel behind LI's H1c failure. Richer records add little to detection; this is a finding about what to share.
- **The privacy story is mixed and needs careful wording.** S3 adds no protection for the flag's leakage. The OPRF clears PT2 on HI only.
- **The federated DP track splits by regime, as on validation:** the HI misses and LI holds for H2a and H2b are the same as at G3.
- **The narrative does not reach 95% grounding** with a 3B local model. Delivered text, after the strict check, retry and template, is 100% claim-consistent.

## 3 Nov: the first HI-Medium run stopped before opening the test

`test-x1` stopped on seed 0 while scoring the test partition: `BudgetExceeded: bank 7 would exceed 74510 evaluations in epoch 1`. That is **before** the opening step, so no test label was read and the access log is empty (`finmesh sealed-log --dataset HI-Medium`).

**Likely cause:** the token budget (A16: twice the largest validation use, 74,510) was sized with validation's candidates, which come from calibration fitted on the end of training. A24 calibrates test with isotonic fitted on validation. If validation has more laundering than the end of training, every probability rises, many more account-windows pass the 0.01 evidence floor, and each asks about its counterparties. On the fixture, this calibration change alone nearly doubles the candidates (570 → 1,008). The same mismatch also feeds the stackers inputs they were not fitted on: the records' probability buckets come from a different calibration.

**Before changing anything,** `finmesh test-traffic --dataset HI-Medium` measures this on your data. It runs about 20–30 min, reads no test label and opens nothing. It reports candidates and the peak token demand per bank and epoch for validation and test, under both calibrations, against the budget. **Your measurement (3 Nov, seed 0):**

| Partition | Calibration | Candidates | Peak tokens | Budget |
| --- | --- | --- | --- | --- |
| validation | end of training (as validated) | 74,784 | 28,244 | 74,510 |
| validation | fitted on validation | 123,995 | 45,179 | 74,510 |
| test | end of training | 119,880 | 162,800 | 74,510 |
| test | fitted on validation | 215,176 | 181,112 | 74,510 |

Two things went wrong in my plan. The validation-fitted calibration nearly doubles the candidates and feeds the fusion models inputs they were not fitted on. And the last three days are much busier: even with the validated calibration, bank 7 needs 5.8 times its validation peak, 2.2 times the budget.

**Your decisions:**

1. The test keeps the validated end-of-training calibration.
2. Every legitimate request is served, as on validation. The A1 attack is still judged at the frozen budget, and the shortfall is reported as a finding on how A16 sized the budget.

Recorded as amendment A24a (`CHANGES.md`, plan section 2a). The code changed, so the plan needs your second signature.

**Pushed with the fix:**

- the corrected X1 test path, with validation output still identical on the fixture;
- per-seed token use, printed by `test-x1` and shown on the results page;
- 12 passing week-18 tests.

## 6 Nov: HI-Medium and LI-Medium done; the narrative's page failed after its 200 cases

Your nights 1 and 2 finished: 13 openings on HI-Medium (X1 seeds 0–4, baselines with both label variants, X5 and the ensemble at seeds 0–2), the same on LI-Medium. The HI-Medium narrative then narrated and **saved all 200 cases**, and stopped while writing its report: `KeyError: 'x6_s2'`. The page writer read a timing field that only a validation run has (on test the attribution tables come from `test-x1`).

Fixed in `narrative_report.py` (writing only; amendment A24b). A new test runs the real test-mode narrative and every page the command writes. Rerunning resumes from the 200 saved cases and does **not** open the test again. The LI-Medium narrative has not run yet.

## What changed in the code

| Change | Why | Effect on validation results |
| --- | --- | --- |
| **Test mode for X1–X3 and the audit, with X6 on the same scores** (`finmesh test-x1`) | Each seed trains as on validation and re-runs the frozen validation side to fit the frozen parameters. It then scores test from features only, logs one opening with a SHA-256 of every score, and only then reads labels | None: one seed is now train → score a partition → evaluate. Validation X1 and X6 outputs are identical to before, number for number (fixture check) |
| **Baselines** (`test-baselines`): FPR points with validation thresholds, touch label, artefact ablation, decomposition, PT4b | Section 8 secondary analyses | Identical (fixture check) |
| **X5 and the ensemble** (`test-x5`, `test-ensemble`) | H2a, H2b and the G3 rule on test, from the saved week-12 models | No change on validation |
| **Narrative on test** (`narrative --test`) | H3b and top-k on test. It uses τ from validation and the X6 test attributor (seed 0). It saves every case, so if Ollama stops the same command resumes without a second opening | No change on validation |
| **The seal tightened** | `slices` refuses the test partition unless it has been opened. A runner refuses a second opening **before** hours of scoring, not at the end. Each opening logs the scores' digest | — |
| **Two determinism fixes** | The A4 audit grouped records in a thread-dependent order. The relational oracle summed probabilities in a thread-dependent order, which moved results by 1e-16. A rerun now gives bit-identical scores, so the digest means something | A4 numbers move by a few points between runs of the old code. Every other number is unchanged |
| **`finmesh test-preflight`** | Checks everything without reading a label: the code is unchanged since the signed commit, inputs exist, which seeds have already opened the test, Ollama, disk | — |
| **`finmesh test-report`** | `docs/eval/test/RESULTS.md`: every rule of the plan applied mechanically | — |
| **Two raters** (`narrative-review --prepare`, then `narrative-review`) | Each rater is scored alone. Their agreement uses Cohen's kappa (linear-weighted for faithfulness and usefulness), and the claim check is compared with the cases both call faithful | — |

## Checks done here

| Check | Result |
| --- | --- |
| Validation outputs before and after the refactor (fixture; X1 with sweeps and audit, 2 seeds; X6; baselines) | **Identical**, except A4, which differed between runs of the *old* code too; it is now deterministic |
| Two identical test runs | Bit-identical scores (same SHA-256) |
| Full test plan on the fixture (`test-x1`, `test-baselines`, `test-x5`, `test-ensemble`, `test-report`) | Runs end to end; 6 openings logged, one per experiment, seed and label variant |
| A rerun after a finished seed | Keeps the saved seed; no new opening |
| A lost result after an opening | Refused before any work; with `--allow-repeat` it reruns, gives the same digest, and is logged as a repeat |
| Narrative stopped mid-run (scripted model) | The rerun resumes at the next case with no second opening |
| Scale stress (SCALE-Tail, 32 M rows, one full test seed with sweeps, audit and X6) | **Not finished here.** It was stopped at the sandbox's 2 h limit while sharing both cores with the test suite. Resident memory stayed between 1.5 and 2.4 GB through the validation half. The test half frees the validation half first, so its peak should match: X1 on HI-Medium validation peaked at 1.75 GB. Your first night will give the real figure |
| New unit tests (`tests/unit/test_week18.py`, 10 tests) | All pass. The fixture budget is raised so there are real gains: per-configuration seeds, Holm, A6 after the opening, X6 on test, the narrative's inputs, resume, refusal and a logged repeat with an identical digest |
| Unit tests, coverage, lint, types, local CI mirror, gitleaks | 294 passed, coverage 81.67%; lint, types and gitleaks clean; the fixture dry run of every test command runs in CI (`test-x1` 88 s + 14 s) |

The fixture's budget yields almost no alerts, so its numbers are zeros. It tests the mechanics, not the science; the unit test raises the budget and checks real gains.

## Steps for you

### 1. Update and check (15 min)

```bash
git pull && uv sync --locked
bash scripts/ci_local.sh            # includes the fixture dry run of every test command
uv run finmesh test-preflight --dataset HI-Medium
uv run finmesh test-preflight --dataset LI-Medium
uv run finmesh test-preflight --dataset HI-Small --only x1
uv run finmesh test-preflight --dataset LI-Small --only x1
```

Every line should read `ok`, except `WARN` for "no frozen commit signed" (until step 2) and for Ollama on nights without the narrative. If a Small dataset shows `FAIL` for its features (they may never have been built in the pooled view), build them; this reads no test label:

```bash
uv run finmesh labels --dataset HI-Small && uv run finmesh features --dataset HI-Small \
  && uv run finmesh features --dataset HI-Small --view pooled      # then the same for LI-Small
```

### 2. Sign the plan (10 min)

Read `docs/protocol/test_plan.md`. If you agree, fill in its three header fields:

- **Frozen commit:** the output of `git rev-parse --short HEAD`, taken right after pulling;
- **Signed off by:** your name;
- **Date:** today.

Then commit and push (`git commit -am "Week 18: test plan signed" && git push`). From then on, the preflight fails if any code file differs from that commit. Documents and results can still be committed.

### 3. Blind review, both raters (about 45 min each, after step 4; before reading the narrative results)

Each of you opens **only your own copy** in a spreadsheet:

- Allaudin: `docs/eval/narrative_HI-Medium_A23_review_allaudin.csv`
- Ravi: `docs/eval/narrative_HI-Medium_A23_review_ravi.csv`

Do not open the `KEY_do_not_open` file or each other's copy, and do not discuss cases until both are done. For each of the 30 rows, use the evidence column only:

- **faithful A / faithful B:** `yes` if every claim in that narrative is supported by the evidence and its readings; `partly` if some claim is unsupported but none is contradicted; `no` if any claim contradicts the evidence.
- **useful A / useful B:** `1` no help to an analyst, `2` some help, `3` clearly helps decide what to check first.
- **prefer:** `A`, `B` or `same`.
- **notes:** anything that surprised you (optional).

Save as CSV with the same name, commit and push both files. Then:

```bash
uv run finmesh narrative-review --dataset HI-Medium
```

This writes `docs/eval/narrative_HI-Medium_A23_review_result.md` (each rater, agreement, claim check against both).

### 4. The test (three or four nights; plan section 5)

```bash
bash scripts/week18.sh HI-Medium 2>&1 | tee week18_HI-Medium.log   # night 1, about 7–8 h
bash scripts/week18.sh LI-Medium 2>&1 | tee week18_LI-Medium.log   # night 2, about 8–9 h
bash scripts/week18.sh narrative 2>&1 | tee week18_narrative.log   # night 3, Ollama on, 10–12 h
bash scripts/week18.sh small     2>&1 | tee week18_small.log       # about 1 h, then the results page
```

Each script runs the preflight first and stops if anything fails. If a script stops (power cut, Ollama stopped), run the same command again: finished steps are skipped, X1 continues from its next seed, and the narrative continues from its next case.

**Only if** `test-x1` crashed *after* opening a seed's test and *before* saving it, the rerun is refused with "already opened ... saved result is missing". Then run that one command by hand with `--allow-repeat`. The log marks it as a repeat and we report it. Never delete anything under `data/sealed/` or `data/test/`.

### 5. Push

```bash
git add docs/eval/test week18_*.log && git commit -m "Week 18: test results" && git push
```

I then write the results into this log and the paper tables.

## Machine-time estimate

| Run | Per Medium dataset | Note |
| --- | --- | --- |
| `test-x1` (5 seeds, sweeps, audit, X6) | 3–4 h | Each seed re-runs its validation side to fit the frozen parameters, then scores test. 1,000 account replicates at test |
| `test-baselines` | 0.5–1 h | |
| `test-x5` | 1–1.5 h | Scoring only, plus the local-only MLPs |
| `test-ensemble` | 1–1.5 h | |
| `narrative --test` | HI about 10 h, LI 2–4 h | As the A23 validation run |
| Small replication (`test-x1 --no-x6 --no-audit`) | about 30 min each | |
