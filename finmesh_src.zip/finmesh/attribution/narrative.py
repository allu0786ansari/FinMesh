"""Constrained case narrative and its grounding test (week 14; amendment A21; H3b).

For a detected case at level S2, the incident's owner gets a short narrative
written by a local language model (llama3.2:3b through Ollama on this machine,
threat ADV-6). The model never decides anything:

* the **typology** comes from the X6 attributor, and only when its cross-fitted
  confidence reaches τ (selective classification, Geifman and El-Yaniv 2017);
  below τ the case is ``UNATTRIBUTED`` and the top three candidates are listed;
* the **evidence** is rendered by a fixed template from what S2 reveals to the
  owner (own features, cross-bank structure, other members' record counters as
  bucket ranges); the model may cite only these fields;
* the **review actions** come from the catalogue entry, never from the model.

Each case gets one JSON-only call (temperature 0, A7). A reply that fails the
structural check gets one schema-constrained retry, then a template narrative.

**H3b grounding** is measured on the raw first replies: valid JSON, typology
equal to the assigned one (or UNATTRIBUTED), cited fields all in the evidence;
target 0.95. Numeric grounding (every number in the narrative appears in the
prompt), retry and fallback rates and latency (target p95 ≤ 30 s) are reported
alongside.

**A22** (after the A21 validation run failed; the A21 path is kept for
reproducibility): plain ``field = value`` evidence, the narrative written before
the constrained fields, 1–4 citations, a digit-free worked example, candidate
descriptions marked as general reference, and **strict grounding** (H3b plus
1–4 citations, numbers only from the evidence, no typology named outside the
candidates), which also triggers the retry and the fallback.
"""

from __future__ import annotations

import json
import re
import statistics
import time
import urllib.error
from collections.abc import Callable
from typing import Any

import numpy as np
import polars as pl

from finmesh.attribution.claims import claim_check, number_words, reading, scope_check
from finmesh.attribution.llm_probe import DEFAULT_MODEL, assert_local, call_ollama
from finmesh.sharing.evidence import load_evidence_schema

UNATTRIBUTED = "UNATTRIBUTED"
TAU_GRID: tuple[float, ...] = tuple(round(0.30 + 0.05 * i, 2) for i in range(14))  # 0.30-0.95
MIN_SELECTIVE_ACCURACY = 0.5
MIN_COVERAGE = 0.10
SAMPLE_N = 200
PER_PATTERN = 25
SAMPLE_SEED = 0
LATENCY_TARGET_S = 30.0
GROUNDING_TARGET = 0.95
NARRATIVE_MAX_CHARS = 900
PROTOCOLS: tuple[str, ...] = ("A21", "A22", "A23", "A25N")  # A25N = A23 + scope (A25 P5)
# Bounds a runaway reply; a cut-off reply fails the check and is retried.
MAX_TOKENS = {"A21": 320, "A22": 400, "A23": 400, "A25N": 400}
TIMEOUT_S = {"A21": 120.0, "A22": 600.0, "A23": 600.0, "A25N": 600.0}
A23_FAMILY = ("A23", "A25N")
MAX_CITED = 4


class ModelUnavailable(RuntimeError):
    """The model server stopped answering (connection refused or reset), as opposed to a slow
    or bad reply. The run stops and saves nothing, so a dead server can never be recorded as
    a run of failed replies (week-14 rerun: Ollama stopped mid-run)."""


def server_down(exc: BaseException) -> bool:
    """A refused or reset connection, not a timeout and not an HTTP error from the model."""
    if isinstance(exc, urllib.error.HTTPError):
        return False
    reason = exc.reason if isinstance(exc, urllib.error.URLError) else exc
    if isinstance(reason, TimeoutError):
        return False
    return isinstance(
        reason, ConnectionRefusedError | ConnectionResetError | ConnectionAbortedError
    ) or "Connection refused" in str(reason)


# A model call: (prompt, format) -> raw response text. Raises on transport failure.
Call = Callable[[str, dict[str, Any] | str], str]

# (field, description shown to the model, source column(s), kind)
OWN_FIELDS: tuple[tuple[str, str, tuple[str, ...], str], ...] = (
    ("own_accounts", "case accounts at your bank", ("own_accounts",), "int"),
    ("own_account_windows", "alerted account-windows at your bank", ("own_rows",), "int"),
    ("own_span_hours", "hours spanned at your bank", ("own_span",), "hours"),
    (
        "own_max_fan_out",
        "max distinct payees of one account",
        ("own_max_fan_out",),
        "int",
    ),
    ("own_max_fan_in", "max distinct payers of one account", ("own_max_fan_in",), "int"),
    (
        "own_mean_pass_through",
        "mean share of inflow paid out again",
        ("own_mean_pass_through",),
        "share",
    ),
    (
        "own_max_cycles",
        "max short cycles through one account",
        ("own_max_cyc2", "own_max_cyc3", "own_max_cyc4"),
        "int",
    ),
    (
        "own_max_gather_scatter",
        "max gather-then-scatter fan",
        ("own_max_gs_min_fan",),
        "int",
    ),
    (
        "own_max_scatter_gather",
        "max scatter-then-gather fan",
        ("own_max_sg_out_max", "own_max_sg_in_max"),
        "int",
    ),
    (
        "own_max_amount_out",
        "max amount paid out by one account in a window",
        ("own_max_amt_out",),
        "amount",
    ),
    (
        "own_max_amount_in",
        "max amount received by one account in a window",
        ("own_max_amt_in",),
        "amount",
    ),
    (
        "own_mean_cross_bank_share",
        "mean share of transfers with other banks",
        ("own_mean_cross_bank_share",),
        "share",
    ),
    (
        "own_mean_new_counterparty_share",
        "mean share of new counterparties",
        ("own_mean_new_cp_share",),
        "share",
    ),
)
CASE_FIELDS: tuple[tuple[str, str, tuple[str, ...], str], ...] = (
    ("case_accounts", "accounts in the linked case", ("n_accounts",), "int"),
    ("case_members", "federation members in the case", ("n_members",), "int"),
    ("case_account_windows", "alerted account-windows in the case", ("n_rows",), "int"),
    ("case_span_hours", "hours spanned by the case", ("span",), "hours"),
)
RECORD_LABELS = {
    "fan_out": "distinct payees",
    "fan_in": "distinct payers",
    "tx_out": "outgoing transfers",
    "tx_in": "incoming transfers",
    "amt_out": "amount paid out",
    "amt_in": "amount received",
    "pass_through": "share of incoming money paid out again",
    "cross_bank_share": "share of transfers with other banks",
    "new_cp_share": "share of new counterparties",
    "delay_min_h": "min hours from money in to money out",
}


# --------------------------------------------------------------------------- abstention
def risk_coverage(confidence: np.ndarray, correct: np.ndarray) -> list[dict[str, Any]]:
    """Selective accuracy and coverage at each τ in the grid (detected schemes only)."""
    n = len(confidence)
    rows = []
    for tau in TAU_GRID:
        keep = confidence >= tau
        rows.append(
            {
                "tau": tau,
                "coverage": float(keep.mean()) if n else 0.0,
                "selective_accuracy": float(correct[keep].mean()) if keep.any() else None,
                "kept": int(keep.sum()),
            }
        )
    return rows


def selective_threshold(confidence: np.ndarray, correct: np.ndarray) -> float | None:
    """The smallest τ with selective accuracy ≥ 0.5 and coverage ≥ 10%; None if none."""
    for r in risk_coverage(confidence, correct):
        acc = r["selective_accuracy"]
        if acc is not None and acc >= MIN_SELECTIVE_ACCURACY and r["coverage"] >= MIN_COVERAGE:
            return float(r["tau"])
    return None


# --------------------------------------------------------------------------- sample
def stratified_sample(
    scheme_ids: np.ndarray,
    patterns: np.ndarray,
    n: int = SAMPLE_N,
    per_pattern: int = PER_PATTERN,
    seed: int = SAMPLE_SEED,
) -> np.ndarray:
    """Indices: up to ``per_pattern`` per pattern at random, then filled at random to ``n``."""
    rng = np.random.default_rng(seed)
    order = np.argsort(scheme_ids, kind="stable")
    kinds = sorted(set(patterns.tolist()))
    # A smaller n shrinks the cap evenly, so no pattern is crowded out (n = 200: 25 each).
    cap = min(per_pattern, max(1, n // max(len(kinds), 1)))
    chosen: list[int] = []
    for p in kinds:
        idx = order[patterns[order] == p]
        chosen += rng.permutation(idx)[:cap].tolist()
    chosen = chosen[:n]
    rest = np.setdiff1d(order, np.array(chosen, dtype=np.int64))
    chosen += rng.permutation(rest)[: max(0, n - len(chosen))].tolist()
    return np.array(sorted(chosen, key=lambda i: scheme_ids[i]), dtype=np.int64)


# --------------------------------------------------------------------------- evidence
def _num(v: float, kind: str, window_hours: int) -> str:
    if kind == "hours":
        return f"{round(v * window_hours):,}"
    if kind == "share":
        return f"{v:.2f}"
    if kind == "amount":
        return f"{v:,.0f}"
    return f"{round(v):,}"


def _value(row: dict[str, Any], cols: tuple[str, ...]) -> float | None:
    vals = [float(v) for v in (row.get(c) for c in cols) if v is not None]
    vals = [v for v in vals if not np.isnan(v)]
    return max(vals) if vals else None


def bucket_range(index: float | None, edges: tuple[float, ...]) -> str:
    """Human range of an evidence bucket (see ``finmesh.sharing.evidence.bucket``)."""
    if index is None or np.isnan(index):
        return "no record from another member"
    i = round(index)

    def e(x: float) -> str:
        return f"{x:,.0f}" if float(x).is_integer() else f"{x:g}"

    if i == 0:
        return f"below {e(edges[0])}"
    if i < len(edges):
        return f"at least {e(edges[i - 1])}, below {e(edges[i])}"
    if i == len(edges):
        return f"{e(edges[-1])} or more"
    return "not reported"


def evidence(row: dict[str, Any], window_hours: int) -> list[dict[str, str]]:
    """The fixed evidence template: what S2 reveals to the incident's owner."""
    out = []
    for section, fields in (("Your bank", OWN_FIELDS), ("Linked case", CASE_FIELDS)):
        for field, label, cols, kind in fields:
            v = _value(row, cols)
            out.append(
                {
                    "section": section,
                    "field": field,
                    "label": label,
                    "value": "not available" if v is None else _num(v, kind, window_hours),
                }
            )
    for name, _, edges in load_evidence_schema().counters:
        out.append(
            {
                "section": "Other members' records (highest bucket)",
                "field": f"others_{name}",
                "label": RECORD_LABELS.get(name, name.replace("_", " ")),
                "value": bucket_range(_value(row, (f"rec_max_c_{name}",)), edges),
            }
        )
    return out


# --------------------------------------------------------------------------- prompt
def _entry_text(entry: dict[str, Any]) -> str:
    flags = "; ".join(entry["red_flags"])
    return f"- {entry['id']} ({entry['name']}): {entry['description']} Red flags: {flags}."


MISSING = ("not available", "no record from another member")


def shown(case: dict[str, Any]) -> list[dict[str, str]]:
    """Evidence lines in the prompt: only fields with a value (shorter, nothing to misread)."""
    return [e for e in case["evidence"] if e["value"] not in MISSING]


def build_prompt(case: dict[str, Any], catalogue: dict[str, Any], protocol: str = "A22") -> str:
    if protocol == "A21":
        return build_prompt_a21(case, catalogue)
    if protocol in A23_FAMILY:
        return build_prompt_a23(case, catalogue)
    return build_prompt_a22(case, catalogue)


def evidence_line(ev: dict[str, str]) -> str:
    """A23 evidence line: the value, its fixed plain-word reading, and its meaning."""
    words = reading(ev["field"], ev["value"])
    said = f"{ev['value']}, {words}" if words else ev["value"]
    return f"{ev['field']} = {said} ({ev['label']})"


def build_prompt_a23(case: dict[str, Any], catalogue: dict[str, Any]) -> str:
    """A23: worded evidence, the reply's shape instead of a content example, and explicit
    rules against the claims A22 got wrong."""
    entries = {e["id"]: e for e in catalogue["entries"]}
    expected = case["assigned"]
    if expected == UNATTRIBUTED:
        decision = (
            "The attributor is not confident about the pattern, so the case is UNATTRIBUTED. "
            "You may say which candidate patterns the analyst could check, but do not claim that "
            "the case matches any of them. Name no pattern that is not a candidate."
        )
        ids = [c["id"] for c in case["candidates"]]
        heading = "Candidate patterns to check"
    else:
        decision = (
            f"The pattern has been assigned: {expected}. Do not argue for another pattern and "
            "name no other pattern."
        )
        ids = [expected]
        heading = "Assigned pattern"
    reference = [
        f"- {line}: {entries[i]['description']}"
        for i, line in zip(ids, _confidence_lines(case), strict=True)
    ]
    lines: list[str] = []
    section = None
    for ev in shown(case):
        if ev["section"] != section:
            section = ev["section"]
            lines.append(f"{section}:")
        lines.append(evidence_line(ev))
    shape = (
        '{"narrative": "<two to four sentences about this case>", '
        '"cited_fields": ["<one to four field names from the evidence>"], '
        f'"typology_id": "{expected}"}}'
    )
    return "\n".join(
        [
            "You help an anti-money-laundering analyst write a short summary of one case.",
            "",
            "Rules:",
            "- Describe only what the evidence lines below state. After each value comes its "
            "meaning in plain words; use those words. Do not add facts, causes, names, accounts "
            "or dates.",
            "- If the words say none, no, one, two or under half, say exactly that. Never "
            "describe such a value as many, several, most or high.",
            "- Copy any number exactly as written. Do not calculate or round.",
            "- The pattern descriptions are general reference: they say what a pattern looks like "
            "in general, NOT what happened in this case. Never present them as observations, and "
            "do not say that money was gathered, split, scattered, layered, cycled or returned "
            "unless an evidence line says so.",
            f"- {decision}",
            "- Do not recommend actions; they are added separately.",
            "- Reply with one JSON object in exactly this shape, replacing the parts in angle "
            "brackets:",
            shape,
            "",
            f"{heading} (general reference, not observations about this case):",
            *reference,
            "",
            "Evidence about this case:",
            *lines,
        ]
    )


def _confidence_lines(case: dict[str, Any]) -> list[str]:
    if case["assigned"] == UNATTRIBUTED:
        return [
            f"{c['id']} (attributor confidence {c['confidence']:.2f})" for c in case["candidates"]
        ]
    return [f"{case['assigned']} (attributor confidence {case['confidence']:.2f})"]


def build_prompt_a22(case: dict[str, Any], catalogue: dict[str, Any]) -> str:
    """A22: plain evidence lines, narrative first, 1-4 citations, reference marked as such."""
    entries = {e["id"]: e for e in catalogue["entries"]}
    expected = case["assigned"]
    if expected == UNATTRIBUTED:
        decision = (
            "The attributor is not confident about the pattern, so the case is UNATTRIBUTED. "
            "You may say which candidate patterns the analyst could check, but do not claim that "
            "the case matches any of them. Name no pattern that is not a candidate."
        )
        ids = [c["id"] for c in case["candidates"]]
        heading = "Candidate patterns to check"
    else:
        decision = (
            f"The pattern has been assigned: {expected}. Do not argue for another pattern and "
            "name no other pattern."
        )
        ids = [expected]
        heading = "Assigned pattern"
    reference = [
        f"- {line}: {entries[i]['description']}"
        for i, line in zip(ids, _confidence_lines(case), strict=True)
    ]
    lines: list[str] = []
    section = None
    for ev in shown(case):
        if ev["section"] != section:
            section = ev["section"]
            lines.append(f"{section}:")
        lines.append(f"{ev['field']} = {ev['value']} ({ev['label']})")
    example = json.dumps(
        {
            "narrative": "Several accounts at your bank received money from many payers and "
            "passed most of it on. Other members report accounts with similar inflows.",
            "cited_fields": ["own_max_fan_in", "own_mean_pass_through", "others_fan_in"],
            "typology_id": expected,
        }
    )
    return "\n".join(
        [
            "You help an anti-money-laundering analyst write a short summary of one case.",
            "",
            "Rules:",
            "- Describe only what the evidence lines below state. Do not add facts, causes, "
            "names, accounts or dates.",
            "- Copy any number exactly as written in the evidence. Do not calculate or round.",
            "- The pattern descriptions are general reference: they say what a pattern looks like "
            "in general, NOT what happened in this case. Never present them as observations.",
            f"- {decision}",
            "- Do not recommend actions; they are added separately.",
            "- Reply with one JSON object with these keys in this order: "
            '"narrative" (two to four plain sentences for the analyst), "cited_fields" (the one '
            "to four field names, written exactly as before the = sign, that your narrative "
            f'relies on most) and "typology_id" (exactly "{expected}").',
            "",
            "Example reply for a different, fictitious case:",
            example,
            "",
            f"{heading} (general reference, not observations about this case):",
            *reference,
            "",
            "Evidence about this case:",
            *lines,
        ]
    )


def build_prompt_a21(case: dict[str, Any], catalogue: dict[str, Any]) -> str:
    """The A21 prompt, kept unchanged so the first validation run stays reproducible."""
    entries = {e["id"]: e for e in catalogue["entries"]}
    if case["assigned"] == UNATTRIBUTED:
        decision = (
            f'The case is UNATTRIBUTED: the attributor is not confident enough. Set "typology_id" '
            f'to "{UNATTRIBUTED}". You may mention the candidate typologies only as possibilities '
            "to check, never as a finding."
        )
        context = [_entry_text(entries[c["id"]]) for c in case["candidates"]]
        conf = "Candidate typologies (attributor confidence): " + ", ".join(
            f"{c['id']} ({c['confidence']:.2f})" for c in case["candidates"]
        )
    else:
        decision = (
            f'The typology is already decided: set "typology_id" to "{case["assigned"]}". '
            "Do not argue for another typology."
        )
        context = [_entry_text(entries[case["assigned"]])]
        conf = f"Attributor confidence: {case['confidence']:.2f}"
    lines = []
    section = None
    for ev in shown(case):
        if ev["section"] != section:
            section = ev["section"]
            lines.append(f"{section}:")
        lines.append(f"- [{ev['field']}] {ev['label']}: {ev['value']}")
    return "\n".join(
        [
            "You help an anti-money-laundering analyst write a short case summary.",
            "Rules:",
            "- Use only the evidence below. Do not invent names, accounts, dates or amounts.",
            "- Copy numbers exactly as written in the evidence. Do not calculate new numbers.",
            f"- {decision}",
            '- "cited_fields": the evidence field names (in square brackets) that your '
            "narrative relies on.",
            '- "narrative": two to four plain sentences for the analyst.',
            "- Do not recommend actions; they are added separately.",
            'Reply with one JSON object with exactly the keys "typology_id", "cited_fields" '
            'and "narrative".',
            "",
            "Typology context:",
            *context,
            conf,
            "",
            "Evidence:",
            *lines,
        ]
    )


def reply_schema(expected: str, fields: list[str], protocol: str = "A22") -> dict[str, Any]:
    """The schema for the constrained retry: only the assigned typology, only real fields."""
    if protocol in ("A22", *A23_FAMILY):
        return {
            "type": "object",
            "properties": {
                "narrative": {"type": "string", "maxLength": NARRATIVE_MAX_CHARS},
                "cited_fields": {
                    "type": "array",
                    "items": {"type": "string", "enum": fields},
                    "minItems": 1,
                    "maxItems": MAX_CITED,
                },
                "typology_id": {"type": "string", "enum": [expected]},
            },
            "required": ["narrative", "cited_fields", "typology_id"],
            "additionalProperties": False,
        }
    return {
        "type": "object",
        "properties": {
            "typology_id": {"type": "string", "enum": [expected]},
            "cited_fields": {"type": "array", "items": {"type": "string", "enum": fields}},
            "narrative": {"type": "string", "maxLength": NARRATIVE_MAX_CHARS},
        },
        "required": ["typology_id", "cited_fields", "narrative"],
        "additionalProperties": False,
    }


# --------------------------------------------------------------------------- checks
_NUMBER = re.compile(r"(?<![\w.])-?\d+(?:,\d{3})*(?:\.\d+)?")


def numbers_in(text: str) -> set[float]:
    return {round(float(m.replace(",", "")), 6) for m in _NUMBER.findall(text)}


def evidence_numbers(case: dict[str, Any]) -> set[float]:
    """A22: the numbers a narrative may use: evidence values and the confidence lines."""
    text = " ".join(e["value"] for e in shown(case)) + " " + " ".join(_confidence_lines(case))
    return numbers_in(text)


_COMMON_WORD_IDS = frozenset({"CYCLE", "STACK", "RANDOM"})


def _mention_patterns(catalogue: dict[str, Any]) -> dict[str, re.Pattern[str]]:
    out = {}
    for e in catalogue["entries"]:
        i = e["id"]
        if i in _COMMON_WORD_IDS:  # ordinary English words: only the upper-case id counts
            out[i] = re.compile(rf"\b{i}\b")
        else:
            body = r"[\s-]?".join(re.escape(part) for part in i.lower().split("-"))
            out[i] = re.compile(rf"\b{body}\b", re.IGNORECASE)
    return out


def typologies_named(text: str, catalogue: dict[str, Any]) -> set[str]:
    """Catalogue typologies a text names (ids; multi-word names in any case or hyphenation)."""
    return {i for i, rx in _mention_patterns(catalogue).items() if rx.search(text)}


def allowed_typologies(case: dict[str, Any]) -> set[str]:
    if case["assigned"] == UNATTRIBUTED:
        return {c["id"] for c in case["candidates"]}
    return {case["assigned"]}


def check_reply(
    text: str,
    expected: str,
    fields: list[str],
    prompt_numbers: set[float],
    allowed: set[str] | None = None,
    catalogue: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """H3b checks on one raw reply, before any repair. With ``allowed`` and ``catalogue``
    (A22) it also judges strict grounding: H3b + 1-4 citations + numbers from the evidence
    + no typology named outside ``allowed``."""
    out: dict[str, Any] = {
        "strict": False,
        "cites_ok": False,
        "mentions_ok": False,
        "named": [],
        "json": False,
        "typology": False,
        "cited": False,
        "grounded": False,
        "numeric": False,
        "cites_any": False,
        "narrative": None,
        "cited_fields": [],
    }
    try:
        reply = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return out
    if not isinstance(reply, dict):
        return out
    out["json"] = True
    narrative = reply.get("narrative")
    cited = reply.get("cited_fields")
    out["typology"] = reply.get("typology_id") == expected
    out["cited"] = isinstance(cited, list) and all(
        isinstance(f, str) and f in fields for f in cited
    )
    ok_text = isinstance(narrative, str) and bool(narrative.strip())
    out["grounded"] = bool(out["typology"] and out["cited"] and ok_text)
    if isinstance(narrative, str) and ok_text:
        out["narrative"] = narrative.strip()
        out["numeric"] = numbers_in(narrative) <= prompt_numbers
    if isinstance(cited, list):
        out["cited_fields"] = [str(f) for f in cited]
        out["cites_any"] = bool(cited)
        out["cites_ok"] = 1 <= len(cited) <= MAX_CITED
    if allowed is not None and catalogue is not None and out["narrative"]:
        named = typologies_named(out["narrative"], catalogue)
        out["named"] = sorted(named)
        out["mentions_ok"] = named <= allowed
    out["strict"] = bool(
        out["grounded"] and out["cites_ok"] and out["numeric"] and out["mentions_ok"]
    )
    return out


def template_narrative(case: dict[str, Any], protocol: str = "A22") -> str:
    """Deterministic fallback, built only from the evidence values (grounded by construction)."""
    if protocol == "A21":
        return template_narrative_a21(case)
    if protocol in A23_FAMILY:
        return template_narrative_a23(case)
    ev = {e["field"]: e["value"] for e in case["evidence"]}
    if case["assigned"] == UNATTRIBUTED:
        what = "The pattern is unattributed; candidates to check: " + ", ".join(
            c["id"] for c in case["candidates"]
        )
    else:
        what = f"Assigned pattern: {case['assigned']}"
    return (
        f"The linked case holds {ev['case_accounts']} accounts at {ev['case_members']} "
        f"federation members over {ev['case_span_hours']} hours, of which {ev['own_accounts']} "
        f"are at your bank. {what}. At your bank, the most distinct payees of one account: "
        f"{ev['own_max_fan_out']}; the most distinct payers: {ev['own_max_fan_in']}; mean share "
        f"of inflow paid out again: {ev['own_mean_pass_through']}."
    )


def template_narrative_a23(case: dict[str, Any]) -> str:
    """A23 template: the evidence values with their fixed readings, neutral wording only."""
    ev = {e["field"]: e["value"] for e in case["evidence"]}

    def said(field: str) -> str:
        v = ev.get(field, "not available")
        words = reading(field, v)
        return f"{v} ({words})" if words else v

    if case["assigned"] == UNATTRIBUTED:
        what = "The pattern is unattributed; candidates to check: " + ", ".join(
            c["id"] for c in case["candidates"]
        )
    else:
        what = f"Assigned pattern: {case['assigned']}"
    return (
        f"The linked case holds {ev['case_accounts']} accounts at {ev['case_members']} "
        f"federation members over {ev['case_span_hours']} hours, of which {ev['own_accounts']} "
        f"are at your bank. {what}. At your bank: largest number of payees of one account, "
        f"{said('own_max_fan_out')}; largest number of payers of one account, "
        f"{said('own_max_fan_in')}; mean pass-through share, {said('own_mean_pass_through')}."
    )


def template_narrative_a21(case: dict[str, Any]) -> str:
    """The A21 template, unchanged."""
    ev = {e["field"]: e["value"] for e in case["evidence"]}
    if case["assigned"] == UNATTRIBUTED:
        what = "The pattern is unattributed; candidates to check: " + ", ".join(
            c["id"] for c in case["candidates"]
        )
    else:
        what = f"Assigned typology: {case['assigned']}"
    return (
        f"{ev['case_accounts']} accounts at {ev['case_members']} federation members are linked "
        f"in this case over {ev['case_span_hours']} hours; {ev['own_accounts']} of them are at "
        f"your bank. {what}. Largest fan-out at your bank: {ev['own_max_fan_out']}; largest "
        f"fan-in: {ev['own_max_fan_in']}; average pass-through: {ev['own_mean_pass_through']}."
    )


# --------------------------------------------------------------------------- cases
def build_case(
    row: dict[str, Any],
    classes: list[str],
    proba: np.ndarray,
    tau: float | None,
    catalogue: dict[str, Any],
    window_hours: int,
) -> dict[str, Any]:
    order = np.argsort(-proba, kind="stable")
    top = [{"id": classes[i], "confidence": float(proba[i])} for i in order[:3]]
    confidence = float(proba[order[0]])
    attributed = tau is not None and confidence >= tau
    assigned = classes[order[0]] if attributed else UNATTRIBUTED
    entries = {e["id"]: e for e in catalogue["entries"]}
    actions = (
        list(entries[assigned]["review_actions"])
        if attributed
        else [entries[c["id"]]["review_actions"][0] for c in top]
    )
    return {
        "scheme_id": int(row["scheme_id"]),
        "pattern": row["pattern"],
        "assigned": assigned,
        "top_prediction": classes[order[0]],
        "confidence": confidence,
        "candidates": top,
        "evidence": evidence(row, window_hours),
        "review_actions": actions,
    }


def _a23_checks(res: dict[str, Any], ev: dict[str, str], known: set[float]) -> dict[str, Any]:
    """A23 additions to strict grounding: claim consistency, number words, no copying."""
    text = res.get("narrative") or ""
    c = claim_check(text, ev)
    words_ok = {round(x, 6) for x in number_words(text)} <= known
    return {
        "consistent": bool(text) and c["consistent"],
        "claims": c["claims"],
        "unsupported": c["unsupported"],
        "copied": c["copied"],
        "number_words_ok": words_ok,
        "strict": bool(res["strict"] and c["consistent"] and not c["copied"] and words_ok),
    }


def narrate(
    case: dict[str, Any], catalogue: dict[str, Any], call: Call, protocol: str = "A22"
) -> dict[str, Any]:
    """One case: JSON-only call, one schema-constrained retry if needed, else the template.

    A21 retries on an H3b failure; A22 on a strict-grounding failure."""
    prompt = build_prompt(case, catalogue, protocol)
    fields = [e["field"] for e in shown(case)]
    expected = case["assigned"]
    known = numbers_in(prompt) if protocol == "A21" else evidence_numbers(case)
    allowed = allowed_typologies(case)
    gate = "grounded" if protocol == "A21" else "strict"
    ev_map = {e["field"]: e["value"] for e in case["evidence"]}
    t0 = time.perf_counter()
    errors: list[str] = []

    def attempt(fmt: dict[str, Any] | str, text: str) -> dict[str, Any]:
        try:
            raw = call(text, fmt)
        except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
            if server_down(exc):
                raise ModelUnavailable(str(exc)) from exc
            errors.append(f"{type(exc).__name__}: {exc}"[:200])
            raw = ""
        res = {"raw": raw, **check_reply(raw, expected, fields, known, allowed, catalogue)}
        if protocol in A23_FAMILY:
            res.update(_a23_checks(res, ev_map, known))
        if protocol == "A25N":
            sc = scope_check(res.get("narrative") or "", ev_map)
            res.update(sc)
            res["strict"] = bool(res["strict"] and sc["scope_ok"])
        return res

    first = attempt("json", prompt)
    first_s = time.perf_counter() - t0
    retry = None
    final_source = "first"
    final = first
    if not first[gate]:
        retry = attempt(
            reply_schema(expected, fields, protocol),
            prompt + "\n\nYour previous reply did not follow the rules. Reply with the JSON "
            "object only.",
        )
        final, final_source = retry, "retry"
        if not retry[gate]:
            final_source = "template"
    narrative = (
        template_narrative(case, protocol) if final_source == "template" else final["narrative"]
    )
    final_named = typologies_named(narrative, catalogue)
    final_claims = claim_check(narrative, ev_map)
    return {
        **case,
        "prompt_chars": len(prompt),
        "first": first,
        "retry": retry,
        "final_source": final_source,
        "narrative": narrative,
        "final_numeric": numbers_in(narrative) <= known,
        "final_mentions_ok": final_named <= allowed,
        "final_consistent": final_claims["consistent"],
        "final_unsupported": final_claims["unsupported"],
        "final_scope_ok": scope_check(narrative, ev_map)["scope_ok"],
        "protocol": protocol,
        "latency_first_s": round(first_s, 3),
        "latency_total_s": round(time.perf_counter() - t0, 3),
        "errors": errors,
    }


UNLOAD_EVERY = 6


def ollama_call(
    url: str,
    model: str,
    timeout: float,
    max_tokens: int = MAX_TOKENS["A22"],
    unload_every: int = UNLOAD_EVERY,
) -> Call:
    """A call to the local model that unloads it (``keep_alive: 0``) every ``unload_every``
    calls. Recent Ollama keeps each finished prompt's state in RAM (about 110 MB each, up to
    8 GB); on the owner's 5.8 GB CPU machine 32 of them pushed the weights out of memory and
    slowed generation about 25-fold. Unloading after every call fixed that, but a CPU reload
    takes about 50 s, longer than the reply. Every 6 calls bounds the cache to about 0.7 GB,
    and a retry still reuses its first call's cached prompt. The replies are unchanged."""
    assert_local(url)
    count = {"n": 0}

    def call(prompt: str, fmt: dict[str, Any] | str) -> str:
        count["n"] += 1
        keep_alive = 0 if unload_every <= 1 or count["n"] % unload_every == 0 else None
        reply = call_ollama(
            url, model, prompt, fmt, timeout, max_tokens=max_tokens, keep_alive=keep_alive
        )
        return str(reply.get("response", ""))

    return call


# --------------------------------------------------------------------------- summary
def _rate(xs: list[bool]) -> float | None:
    return float(np.mean(xs)) if xs else None


def _wilson(k: int, n: int) -> dict[str, float | None]:
    if not n:
        return {"estimate": None, "low": None, "high": None}
    z, p = 1.959964, k / n
    centre = (p + z * z / (2 * n)) / (1 + z * z / n)
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return {"estimate": p, "low": float(centre - half), "high": float(centre + half)}


def _count_claims(xs: list[str]) -> dict[str, int]:
    out: dict[str, int] = {}
    for x in xs:
        out[x] = out.get(x, 0) + 1
    return dict(sorted(out.items()))


def summarise(results: list[dict[str, Any]]) -> dict[str, Any]:
    n = len(results)
    grounded = [r["first"]["grounded"] for r in results]
    lat = sorted(r["latency_total_s"] for r in results)
    attributed = [r for r in results if r["assigned"] != UNATTRIBUTED]
    unattributed = [r for r in results if r["assigned"] == UNATTRIBUTED]
    by_pattern: dict[str, dict[str, Any]] = {}
    for p in sorted({r["pattern"] for r in results}):
        rs = [r for r in results if r["pattern"] == p]
        by_pattern[p] = {
            "cases": len(rs),
            "attributed": sum(r["assigned"] != UNATTRIBUTED for r in rs),
            "correct": sum(r["assigned"] == p for r in rs),
            "grounded": _rate([r["first"]["grounded"] for r in rs]),
            "strict": _rate([bool(r["first"].get("strict")) for r in rs]),
            "top3": _rate([p in {c["id"] for c in r["candidates"]} for r in rs]),
        }
    strict = [bool(r["first"].get("strict")) for r in results]
    return {
        "cases": n,
        "strict_grounding": _wilson(sum(strict), n),
        "first_reply_strict": {
            k: _rate([bool(r["first"].get(k)) for r in results])
            for k in ("cites_ok", "mentions_ok")
        },
        "final_mentions_ok": _rate([bool(r.get("final_mentions_ok", True)) for r in results]),
        "final_consistent": _rate([bool(r.get("final_consistent")) for r in results]),
        "first_scope_ok": _rate([bool(r["first"].get("scope_ok", True)) for r in results]),
        "final_scope_ok": _rate([bool(r.get("final_scope_ok", True)) for r in results]),
        "first_consistent": _rate(
            [bool(r["first"].get("consistent")) for r in results if "consistent" in r["first"]]
        ),
        "first_unsupported": _count_claims(
            [u for r in results for u in r["first"].get("unsupported", [])]
        ),
        "final_unsupported": _count_claims(
            [u for r in results for u in r.get("final_unsupported", [])]
        ),
        "answered": sum(bool(r["first"]["raw"]) for r in results),
        "grounded_when_answered": _rate(
            [r["first"]["grounded"] for r in results if r["first"]["raw"]]
        ),
        "strict_when_answered": _rate(
            [bool(r["first"].get("strict")) for r in results if r["first"]["raw"]]
        ),
        "H3b": {
            "grounding": _wilson(sum(grounded), n),
            "target": GROUNDING_TARGET,
            "met_on_validation": bool(n and np.mean(grounded) >= GROUNDING_TARGET),
        },
        "first_reply": {
            k: _rate([bool(r["first"][k]) for r in results])
            for k in ("json", "typology", "cited", "numeric", "cites_any")
        },
        "retry_rate": _rate([r["retry"] is not None for r in results]),
        "retry_grounded": _rate([r["retry"]["grounded"] for r in results if r["retry"]]),
        "fallback_rate": _rate([r["final_source"] == "template" for r in results]),
        "final_numeric": _rate([r["final_numeric"] for r in results]),
        "errors": sum(bool(r["errors"]) for r in results),
        "latency_s": {
            "p50": statistics.median(lat) if lat else None,
            "p95": lat[min(n - 1, int(np.ceil(0.95 * n)) - 1)] if lat else None,
            "max": lat[-1] if lat else None,
            "target_p95": LATENCY_TARGET_S,
        },
        "attributed": {
            "cases": len(attributed),
            "accuracy": _rate([r["assigned"] == r["pattern"] for r in attributed]),
        },
        "unattributed": {
            "cases": len(unattributed),
            "top3_contains_truth": _rate(
                [r["pattern"] in {c["id"] for c in r["candidates"]} for r in unattributed]
            ),
        },
        "by_pattern": by_pattern,
    }


# --------------------------------------------------------------------------- top-k (A22)
def _ci(draws: np.ndarray, est: float) -> dict[str, float]:
    return {
        "estimate": float(est),
        "low": float(np.quantile(draws, 0.025)),
        "high": float(np.quantile(draws, 0.975)),
    }


def topk_hits(
    patterns: np.ndarray, detected: np.ndarray, classes: list[str], proba: np.ndarray, k: int
) -> np.ndarray:
    """Per scheme: detected and the true pattern among the attributor's top k (end to end)."""
    out = np.zeros(len(patterns), dtype=bool)
    idx = np.nonzero(detected)[0]
    if len(idx):
        top = np.argsort(-proba[idx], axis=1, kind="stable")[:, :k]
        names = np.array(classes, dtype=object)[top]
        out[idx] = (names == patterns[idx, None]).any(axis=1)
    return out


def frequency_top3(patterns: np.ndarray, detected: np.ndarray, fold: np.ndarray) -> np.ndarray:
    """Baseline: the three most frequent patterns of the other time half (cross-fitted)."""
    out = np.zeros(len(patterns), dtype=bool)
    for k in (0, 1):
        train = detected & (fold == k)
        apply = detected & (fold != k)
        src = patterns[train] if train.any() else patterns[detected]
        if not apply.any() or not len(src):
            continue
        labels, counts = np.unique(src, return_counts=True)
        top = set(labels[np.argsort(-counts, kind="stable")[:3]].tolist())
        out[apply] = np.isin(patterns[apply], list(top))
    return out


def topk_analysis(
    tables: dict[str, dict[str, Any]],
    reps: int = 1000,
    frequency_source: np.ndarray | None = None,
) -> dict[str, Any]:
    """Top-1 and top-3 accuracy per level, end to end and on detected schemes, with a scheme
    bootstrap, the paired S2 - S0 difference and the frequency and chance baselines.

    ``frequency_source`` (test): the detected validation schemes' patterns; the frequency
    baseline is then their three most frequent patterns instead of the other time half's.
    """
    aligned = {lv: t["table"].with_row_index("_row").sort("scheme_id") for lv, t in tables.items()}
    first = next(iter(aligned.values()))
    patterns = first["pattern"].to_numpy().astype(str)
    n = len(patterns)
    rng = np.random.default_rng(0)
    idx = rng.integers(0, n, size=(reps, n)) if n else np.zeros((reps, 0), dtype=int)
    hits: dict[str, np.ndarray] = {}
    out: dict[str, Any] = {"schemes": n, "levels": {}}
    for lv, t in aligned.items():
        assert (t["pattern"].to_numpy().astype(str) == patterns).all()
        det = t["incident"].is_not_null().to_numpy()
        proba = tables[lv]["p"][t["_row"].to_numpy()]
        level: dict[str, Any] = {"detected_share": float(det.mean()) if n else None}
        for k in (1, 3):
            h = topk_hits(patterns, det, tables[lv]["classes"], proba, k)
            hits[f"{lv}/top{k}"] = h
            level[f"top{k}"] = _ci(h[idx].mean(axis=1), h.mean()) if n else None
            level[f"top{k}_detected"] = float(h[det].mean()) if det.any() else None
        if lv == "S2":
            if frequency_source is None:
                f = frequency_top3(patterns, det, t["fold"].to_numpy())
            else:
                labels, counts = np.unique(frequency_source, return_counts=True)
                top = labels[np.argsort(-counts, kind="stable")[:3]].tolist()
                f = det & np.isin(patterns, top)
            hits["S2/frequency_top3"] = f
            level["frequency_top3"] = _ci(f[idx].mean(axis=1), f.mean()) if n else None
            level["frequency_top3_detected"] = float(f[det].mean()) if det.any() else None
            level["chance_top3_detected"] = 3 / len(tables[lv]["classes"])
        out["levels"][lv] = level

    def diff(a: str, b: str) -> dict[str, float]:
        d = hits[a].astype(float) - hits[b].astype(float)
        return _ci(d[idx].mean(axis=1), d.mean())

    comps: dict[str, Any] = {}
    if n and {"S0/top3", "S2/top3"} <= hits.keys():
        comps["S2 - S0 (top 3)"] = diff("S2/top3", "S0/top3")
        comps["S2 - S0 (top 1)"] = diff("S2/top1", "S0/top1")
    if n and "S2/frequency_top3" in hits:
        comps["S2 top 3 - frequency top 3"] = diff("S2/top3", "S2/frequency_top3")
    out["comparisons"] = comps
    return out


# --------------------------------------------------------------------------- test (week 18)
def _run_narrative_test(
    paths: Any,
    option: str,
    n: int,
    model: str,
    url: str,
    timeout: float | None,
    call: Call | None,
    progress: Callable[[str], None] | None,
    protocol: str,
    allow_repeat: bool,
) -> dict[str, Any]:
    import hashlib

    from finmesh.eval.sealed import EvalStore, open_sealed_test, opened_before
    from finmesh.eval.split_io import load_plan
    from finmesh.training.sealed_runs import _load, _save, test_dir
    from finmesh.training.x6 import load_catalogue

    if protocol != "A23":
        return {"error": "only the frozen protocol A23 runs on test"}
    folder = test_dir(paths, option)
    inputs = folder / "narrative_inputs.pkl"
    if not inputs.exists():
        return {
            "error": f"{inputs} is missing; run `finmesh test-x1 --dataset {paths.name}` first "
            "(its seed 0 saves the attribution tables the narrative uses)"
        }
    t0 = time.perf_counter()
    if call is None:
        call = ollama_call(
            url, model, timeout or TIMEOUT_S[protocol], max_tokens=MAX_TOKENS[protocol]
        )
        try:  # fail fast, before the seal is touched
            call('Reply with the JSON object {"ok": true}.', "json")
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            return {"error": f"cannot reach Ollama at {url} ({exc}); start it with `ollama serve`"}
    digest = hashlib.sha256(inputs.read_bytes()).hexdigest()
    got = _load(inputs)
    config = {"experiment": f"narrative-{protocol}", "dataset": paths.name, "option": option}
    ckpt = folder / f"narrative_{protocol}_cases.pkl"
    done: list[dict[str, Any]] = []
    if ckpt.exists():
        saved = _load(ckpt)
        if saved["inputs_sha256"] == digest and saved["n"] == n:
            done = saved["results"]
    store = EvalStore(paths, option)
    first = opened_before(paths, config, int(got["seed"]))
    if first is None or (not done and allow_repeat):
        part = open_sealed_test(
            store,
            config,
            int(got["seed"]),
            "week 18: A23 narratives (H3b) and top-k attribution on test",
            allow_repeat=allow_repeat,
            extra={"inputs_sha256": digest, "model": model},
        )
        truth = dict(part.schemes.select("scheme_id", "pattern").iter_rows())
        for lv in got["test"].values():
            for sid, pat in lv["table"].select("scheme_id", "pattern").iter_rows():
                if truth.get(sid) != pat:
                    raise RuntimeError("saved test tables disagree with the opened test schemes")
    elif not done:
        return {
            "error": f"the narrative already opened the test on {first['time']} and left no "
            "saved cases; rerun with --allow-repeat only if that run crashed (logged)"
        }
    catalogue = load_catalogue()
    window_hours = int(load_plan(paths).window_hours)
    val = got["val"]["S2"]
    det_v = val["table"]["incident"].is_not_null().to_numpy()
    idx_v = np.nonzero(det_v)[0]
    pat_v = val["table"]["pattern"].to_numpy().astype(str)
    p_v = val["p"][idx_v]
    classes: list[str] = val["classes"]
    conf_v = p_v.max(axis=1) if len(idx_v) else np.zeros(0)
    correct_v = np.array(classes, dtype=object)[p_v.argmax(axis=1)] == pat_v[idx_v]
    tau = selective_threshold(conf_v, correct_v)  # frozen: the validation rule's value

    test = got["test"]["S2"]
    table: pl.DataFrame = test["table"]
    proba: np.ndarray = test["p"]
    det = table["incident"].is_not_null().to_numpy()
    patterns = table["pattern"].to_numpy().astype(str)
    idx_det = np.nonzero(det)[0]
    p_det = proba[idx_det]
    conf = p_det.max(axis=1) if len(idx_det) else np.zeros(0)
    correct = np.array(classes, dtype=object)[p_det.argmax(axis=1)] == patterns[idx_det]
    pick = idx_det[stratified_sample(table["scheme_id"].to_numpy()[det], patterns[det], n=n)]
    rows = table.to_dicts()
    results = list(done)
    if progress and done:
        progress(f"resuming after {len(done)} saved cases")
    for k in range(len(done), len(pick)):
        case = build_case(rows[pick[k]], classes, proba[pick[k]], tau, catalogue, window_hours)
        try:
            results.append(narrate(case, catalogue, call, protocol))
        except ModelUnavailable as exc:
            return {
                "error": f"the model server stopped answering at case {k + 1} of {len(pick)} "
                f"({exc}); {len(results)} cases are saved. Start `ollama serve` and run the "
                "same command again: it resumes"
            }
        _save(ckpt, {"inputs_sha256": digest, "n": n, "results": results})
        if progress and (k + 1) % 25 == 0:
            progress(f"narratives {k + 1}/{len(pick)}")
    return {
        "dataset": paths.name,
        "option": option,
        "split": "test",
        "protocol": protocol,
        "topk": topk_analysis(got["test"], frequency_source=pat_v[idx_v]),
        "level": "S2",
        "seed": int(got["seed"]),
        "model": model,
        "decoding": "json-only first, schema-constrained retry, template fallback",
        "timeout_s": timeout or TIMEOUT_S[protocol],
        "inputs_sha256": digest,
        "selective": {
            "tau": tau,
            "tau_from": "validation (frozen)",
            "grid": risk_coverage(conf, correct),
            "detected_schemes": int(det.sum()),
            "schemes": len(det),
            "accuracy_detected": float(correct.mean()) if len(correct) else None,
            "rule": "smallest tau with selective accuracy >= 0.5 and coverage >= 10%",
        },
        "summary": summarise(results),
        "cases": results,
        "seconds": {"total": round(time.perf_counter() - t0, 1)},
        "peak_anon_mb": None,
    }


# --------------------------------------------------------------------------- driver
def run_narrative(
    paths: Any,
    option: str = "B8",
    n: int = SAMPLE_N,
    model: str = DEFAULT_MODEL,
    url: str = "http://localhost:11434",
    timeout: float | None = None,
    call: Call | None = None,
    progress: Callable[[str], None] | None = None,
    protocol: str = "A23",
    split: str = "val",
    allow_repeat: bool = False,
) -> dict[str, Any]:
    """The narrative run. ``split`` "test" (week 18) reads the tables the X1+X6 test run
    saved (attributor fitted on validation, applied to test; tau from validation), logs its
    own opening, and saves each case as it is done, so a stopped model server loses
    nothing: the same command resumes."""
    from finmesh.eval.split_io import load_plan
    from finmesh.sysinfo import AnonPeak
    from finmesh.training.x6 import load_catalogue, run_seed_x6

    if split == "test":
        return _run_narrative_test(
            paths, option, n, model, url, timeout, call, progress, protocol, allow_repeat
        )

    if protocol not in PROTOCOLS:
        raise ValueError(f"unknown narrative protocol {protocol!r}; use one of {PROTOCOLS}")
    t0 = time.perf_counter()
    if call is None:
        call = ollama_call(
            url, model, timeout or TIMEOUT_S[protocol], max_tokens=MAX_TOKENS[protocol]
        )
        try:  # untimed warm-up, before the expensive part: fail fast if Ollama is down
            call('Reply with the JSON object {"ok": true}.', "json")
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            return {"error": f"cannot reach Ollama at {url} ({exc}); start it with `ollama serve`"}
    catalogue = load_catalogue()
    window_hours = int(load_plan(paths).window_hours)
    with AnonPeak() as anon:
        levels = ("S2",) if protocol == "A21" else ("S0", "S2")
        r = run_seed_x6(paths, option, SAMPLE_SEED, progress, levels=levels, keep_tables=True)
        t_x6 = time.perf_counter() - t0
        got = r["tables"]["S2"]
        table: pl.DataFrame = got["table"]
        classes: list[str] = got["classes"]
        proba: np.ndarray = got["p"]
        det = table["incident"].is_not_null().to_numpy()
        patterns = table["pattern"].to_numpy().astype(str)
        idx_det = np.nonzero(det)[0]
        p_det = proba[idx_det]  # cross-fitted, defined for every detected scheme
        conf = p_det.max(axis=1) if len(idx_det) else np.zeros(0)
        correct = np.array(classes, dtype=object)[p_det.argmax(axis=1)] == patterns[idx_det]
        tau = selective_threshold(conf, correct)
        pick = idx_det[stratified_sample(table["scheme_id"].to_numpy()[det], patterns[det], n=n)]
        rows = table.to_dicts()
        results = []
        for k, i in enumerate(pick):
            case = build_case(rows[i], classes, proba[i], tau, catalogue, window_hours)
            try:
                results.append(narrate(case, catalogue, call, protocol))
            except ModelUnavailable as exc:
                return {
                    "error": f"the model server stopped answering at case {k + 1} of "
                    f"{len(pick)} ({exc}); nothing was saved. Start `ollama serve` and run "
                    "the same command again"
                }
            if progress and (k + 1) % 25 == 0:
                progress(f"narratives {k + 1}/{len(pick)}")
    return {
        "dataset": paths.name,
        "option": option,
        "protocol": protocol,
        "topk": topk_analysis(r["tables"]) if protocol != "A21" else None,
        "level": "S2",
        "seed": SAMPLE_SEED,
        "model": model,
        "decoding": "json-only first, schema-constrained retry, template fallback",
        "timeout_s": timeout or TIMEOUT_S[protocol],
        "selective": {
            "tau": tau,
            "grid": risk_coverage(conf, correct),
            "detected_schemes": int(det.sum()),
            "schemes": len(det),
            "accuracy_detected": float(correct.mean()) if len(correct) else None,
            "rule": "smallest tau with selective accuracy >= 0.5 and coverage >= 10%",
        },
        "summary": summarise(results),
        "cases": results,
        "seconds": {"x6_s2": round(t_x6, 1), "total": round(time.perf_counter() - t0, 1)},
        "peak_anon_mb": anon.mb,
    }


__all__ = [
    "PROTOCOLS",
    "TAU_GRID",
    "UNATTRIBUTED",
    "ModelUnavailable",
    "bucket_range",
    "build_case",
    "build_prompt",
    "check_reply",
    "evidence",
    "evidence_numbers",
    "narrate",
    "numbers_in",
    "risk_coverage",
    "run_narrative",
    "selective_threshold",
    "server_down",
    "stratified_sample",
    "summarise",
    "template_narrative",
    "topk_analysis",
    "typologies_named",
]
