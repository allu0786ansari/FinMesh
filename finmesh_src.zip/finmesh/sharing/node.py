"""A bank node: its evidence store, token index and response policy.

The node answers an :class:`EvidenceRequest` at its sharing level:

* **S0**: sharing off; the node never answers (and never asks).
* **S1**: alert flag and time bucket only: whether the token's account had an
  alert in the requested windows, and the latest such window.
* **S2**: the full minimised record of the latest account-window in range
  (alerted or above the evidence floor), plus the alert flag.
* **S3**: the S2 record released through local differential privacy
  (``finmesh.sharing.ldp``): every field but the time bucket and alert flag
  through k-ary randomised response, memoised per record, with a per-account
  epoch budget; over budget, the S1 answer. Every request gets a record: a
  dummy when none exists, and the time field is the end of the requested
  range (A16), so existence is as private as the values.
* **S4**: the S2 record plus the autoencoder's window embedding (the leakage
  upper reference).
* **PD** (progressive disclosure): the S1 answer by default; the S2 record
  only when the requester's score bucket is at least ``tau``.

Answering a request also tells the responder that a peer asked about one of
its records, and the requester's score bucket (``inbound``); its own triage
may use that, which is itself a disclosure the attacks of weeks 8-9 measure.

The token index maps (epoch, token) to the node's own records; it is built by
tokenising the node's own accounts through the token service. The account
never appears in a message.
"""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import polars as pl

from finmesh.matching.tokens import EPOCH_WINDOWS, TokenClient, epoch_of, identifier
from finmesh.sharing.evidence import S4_FIELDS, WIRE_FIELDS
from finmesh.sharing.ldp import LdpReleaser, dummy_wire
from finmesh.sharing.messages import EvidenceRecordWire, EvidenceRequest, EvidenceResponse
from finmesh.sharing.requests import ReceivedStore, RequestGuard


@dataclass
class BankNode:
    member: int
    level: str
    tokens: TokenClient
    guard: RequestGuard
    records: pl.DataFrame
    received: ReceivedStore = field(default_factory=ReceivedStore)
    index: dict[tuple[int, bytes], list[int]] = field(default_factory=dict)
    # What a responder learns from requests: which of its own records a peer asked
    # about, and the requester's score bucket (row, bucket). Used by its own triage.
    inbound: list[tuple[int, int]] = field(default_factory=list)
    ldp: LdpReleaser | None = None  # S3 only
    tau: int | None = None  # PD only: lowest requester bucket that gets a record
    # A25 P3, S1 only: the alert flag answered only to requesters with bucket >= flag_tau,
    # and/or through binary randomised response at flag_eps (memoised per account and epoch).
    flag_eps: float | None = None
    flag_tau: int | None = None
    flag_seed: int = 0
    disclosed: set[int] = field(default_factory=set)  # record rows released at S2+ (any form)
    _flag_memo: dict[tuple[Any, int], bool] = field(default_factory=dict)
    _win: Any = None
    _alert_arr: Any = None
    _acct: Any = None
    _wire: Any = None

    def build_index(self) -> int:
        """Tokenise the node's record accounts per epoch; returns tokens queried."""
        before = self.tokens.queries
        recs = self.records.with_row_index("row").with_columns(
            (pl.col("window") // EPOCH_WINDOWS).alias("epoch")
        )
        self._win = self.records["window"].to_numpy()
        self._alert_arr = self.records["alert"].to_numpy()
        self._acct = self.records["account"].to_numpy()
        fields = S4_FIELDS if self.level == "S4" else WIRE_FIELDS
        self._wire = self.records.select(fields).cast(pl.Int64).to_numpy()
        index: dict[tuple[int, bytes], list[int]] = defaultdict(list)
        for (epoch,), part in recs.sort("window").group_by(["epoch"], maintain_order=True):
            accounts = part["account"].to_list()
            toks = self.tokens.tokens(int(epoch), [identifier(a) for a in accounts])
            for row, tok in zip(part["row"].to_list(), toks, strict=True):
                index[(int(epoch), tok)].append(int(row))
        self.index = dict(index)
        return self.tokens.queries - before

    def respond(self, request: EvidenceRequest, now: int) -> EvidenceResponse:
        reason = self.guard.refuse_reason(request, now)
        if reason is not None:
            return EvidenceResponse(request.request_id, self.member, self.level, "refused")
        rows = [
            r
            for r in self.index.get((request.epoch, request.token), [])
            if request.window_lo <= self._window(r) <= request.window_hi
        ]
        alerted = [r for r in rows if self._alert(r)]
        alert_window = max((self._window(r) for r in alerted), default=-1)
        flag_only = self.level == "S1" or (
            self.level == "PD" and request.requester_bucket < (self.tau or 0)
        )
        if rows:
            self.inbound.append((max(rows, key=self._window), request.requester_bucket))
        if self.level == "S3":
            return self._respond_s3(request, rows, alerted, alert_window)
        if self.level == "S1" and (self.flag_eps is not None or self.flag_tau is not None):
            return self._protected_flag(request, rows, bool(alerted), alert_window)
        if not rows:
            return EvidenceResponse(request.request_id, self.member, self.level, "no_record")
        latest = max(rows, key=self._window)
        values: tuple[int, ...] | None = None
        if not flag_only:
            values = tuple(int(v) for v in self._wire[latest])
        if values is None:  # S1 content: the alert flag and its time bucket
            status = "ok" if alerted else "no_record"
            return EvidenceResponse(
                request.request_id, self.member, self.level, status, bool(alerted), alert_window
            )
        self.disclosed.add(latest)
        return EvidenceResponse(
            request.request_id,
            self.member,
            self.level,
            "ok",
            bool(alerted),
            alert_window,
            EvidenceRecordWire(request.token, values),
        )

    def _protected_flag(
        self, request: EvidenceRequest, rows: list[int], alerted: bool, alert_window: int
    ) -> EvidenceResponse:
        """A25 P3: the gated and/or randomised S1 flag. A gated-out requester gets the
        plain negative answer. Randomised response applies to **every** queried account,
        with or without a record (a record's existence would otherwise show through): the
        true bit is kept with probability e^eps / (1 + e^eps), drawn once per account (or
        token, without a record) and epoch, so the bit is eps-locally private. A reported
        flag without a true alert carries the request's own time bucket."""
        if self.flag_tau is not None and request.requester_bucket < self.flag_tau:
            return EvidenceResponse(request.request_id, self.member, self.level, "no_record")
        bit = alerted
        if self.flag_eps is not None:
            subject: Any = int(self._acct[rows[0]]) if rows else request.token
            key = (subject, int(request.epoch))
            if key not in self._flag_memo:
                sid = subject if isinstance(subject, int) else int.from_bytes(subject[:8], "big")
                seq = [self.flag_seed, self.member, sid, key[1]]
                rng = np.random.default_rng(seq)
                keep = math.exp(self.flag_eps) / (1.0 + math.exp(self.flag_eps))
                self._flag_memo[key] = bool(rng.random() < keep)
            bit = alerted if self._flag_memo[key] else not alerted
        if not bit:
            return EvidenceResponse(request.request_id, self.member, self.level, "no_record")
        when = alert_window if alerted else int(request.window_hi)
        return EvidenceResponse(request.request_id, self.member, self.level, "ok", True, when)

    def _respond_s3(
        self, request: EvidenceRequest, rows: list[int], alerted: list[int], alert_window: int
    ) -> EvidenceResponse:
        """Every request gets an ε-LDP record: the latest real one, or a dummy (A16)."""
        assert self.ldp is not None, "S3 needs an LdpReleaser"
        window_field = WIRE_FIELDS.index("window")
        epoch_rows = self.index.get((request.epoch, request.token), [])
        subject: Any = int(self._acct[epoch_rows[0]]) if epoch_rows else request.token
        if rows:
            latest = max(rows, key=self._window)
            wire = [int(v) for v in self._wire[latest]]
            memo: Any = (latest, request.epoch)  # fresh noise after key rotation
        else:
            latest = -1
            wire = list(dummy_wire(request.window_hi))
            memo = ("dummy", subject, request.epoch)
        wire[window_field] = request.window_hi  # the record's own window would reveal existence
        values = self.ldp.release(memo, subject, request.epoch, tuple(wire))
        if values is None:  # over the account's epoch budget: the S1 answer
            status = "ok" if alerted else "no_record"
            return EvidenceResponse(
                request.request_id, self.member, "S3", status, bool(alerted), alert_window
            )
        if latest >= 0:
            self.disclosed.add(latest)
        return EvidenceResponse(
            request.request_id,
            self.member,
            "S3",
            "ok",
            bool(alerted),
            alert_window,
            EvidenceRecordWire(request.token, values),
        )

    def _window(self, row: int) -> int:
        return int(self._win[row])

    def _alert(self, row: int) -> bool:
        return bool(self._alert_arr[row])

    def subject(self, request: EvidenceRequest, window: int) -> int | None:
        """The node's own account behind a token, for the harness's evaluation only."""
        for r in self.index.get((request.epoch, request.token), []):
            if self._window(r) == window:
                return int(self._acct[r])
        return None


def request_epochs(window: int, first_allowed: int, lookback: int) -> list[tuple[int, int, int]]:
    """(epoch, window_lo, window_hi) ranges covering [window - lookback + 1, window]."""
    lo = max(first_allowed, window - lookback + 1)
    out = []
    for e in sorted({epoch_of(lo), epoch_of(window)}):
        e_lo, e_hi = e * EPOCH_WINDOWS, (e + 1) * EPOCH_WINDOWS - 1
        out.append((e, max(lo, e_lo), min(window, e_hi)))
    return out
